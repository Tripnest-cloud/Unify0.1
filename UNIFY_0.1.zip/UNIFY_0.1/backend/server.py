import os
from pathlib import Path
from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

BASE = Path(__file__).resolve().parent.parent
FRONTEND = BASE / "frontend"

app = FastAPI(title="UNIFY 0.1")

# Serve the UNIFY web interface.
app.mount("/assets", StaticFiles(directory=str(BASE / "assets")), name="assets")

class ChatRequest(BaseModel):
    message: str

@app.get("/")
def home():
    return FileResponse(FRONTEND / "index.html")

@app.get("/style.css")
def style():
    return FileResponse(FRONTEND / "style.css", media_type="text/css")

@app.get("/app.js")
def javascript():
    return FileResponse(FRONTEND / "app.js", media_type="application/javascript")

@app.post("/api/chat")
def chat(request: ChatRequest):
    # The UI is complete, but the AI provider is intentionally not
    # hard-coded here. Add your provider/API integration securely
    # through environment variables in the next build.
    if not request.message.strip():
        return {"reply": "Please enter a message."}
    return {
        "reply": (
            "UNIFY 0.1 received your message. "
            "The interface and backend connection are working. "
            "Connect an AI provider in the backend to enable live AI responses."
        )
    }
