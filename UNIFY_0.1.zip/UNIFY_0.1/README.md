# UNIFY 0.1

A first real UNIFY application build.

## Included
- Mobile-friendly AI chat interface
- UNIFY branding and supplied logo
- New chat
- File attachment UI
- Backend API endpoint
- Project structure ready for real AI/search/file integrations

## Run locally

Install Python 3.10+.

From this folder:

    pip install -r backend/requirements.txt
    uvicorn backend.server:app --reload

Then open:

    http://127.0.0.1:8000

## Important
UNIFY 0.1 is the product shell and backend foundation. It does not pretend to contain a private AI model or unlimited services. Real AI, web search, image generation, file analysis, authentication, and storage must be connected through their respective APIs/services in later versions.
