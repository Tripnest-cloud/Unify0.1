const chat=document.getElementById('chat');
const form=document.getElementById('composer');
const input=document.getElementById('message');
const fileInput=document.getElementById('fileInput');
const welcome=document.getElementById('welcome');
const sidebar=document.querySelector('.sidebar');

function addMessage(text, role='user'){
  if(welcome) welcome.remove();
  const row=document.createElement('div');
  row.className='message '+role;
  const bubble=document.createElement('div');
  bubble.className='bubble';
  bubble.textContent=text;
  row.appendChild(bubble);
  chat.appendChild(row);
  chat.scrollTop=chat.scrollHeight;
  return row;
}

function addAssistant(text){
  const row=addMessage(text,'assistant');
  return row;
}

async function askUnify(message){
  const thinking=addMessage('Thinking…','assistant');
  thinking.querySelector('.bubble').classList.add('thinking');
  try{
    const response=await fetch('/api/chat',{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({message})
    });
    const data=await response.json();
    thinking.remove();
    if(!response.ok) throw new Error(data.detail || 'Request failed');
    addAssistant(data.reply);
  }catch(error){
    thinking.remove();
    addAssistant('UNIFY is running in interface-only mode right now. Connect the backend and AI API to enable live answers.\n\nError: '+error.message);
  }
}

form.addEventListener('submit', async e=>{
  e.preventDefault();
  const message=input.value.trim();
  if(!message)return;
  addMessage(message,'user');
  input.value='';
  input.style.height='auto';
  await askUnify(message);
});

input.addEventListener('input',()=>{
  input.style.height='auto';
  input.style.height=Math.min(input.scrollHeight,140)+'px';
});

document.querySelectorAll('[data-prompt]').forEach(button=>{
  button.addEventListener('click',()=>{
    input.value=button.dataset.prompt;
    input.focus();
  });
});

document.getElementById('newChat').onclick=()=>location.reload();
document.getElementById('menu').onclick=()=>sidebar.classList.toggle('open');

fileInput.addEventListener('change',()=>{
  const file=fileInput.files[0];
  if(!file)return;
  addMessage('Attached file: '+file.name,'user');
  addAssistant('File attachment is visible in UNIFY 0.1. Full file analysis will be connected in the next backend module.');
});
